#include "Arithmetic.h"
#define MAX(a,b) a>b?a:b

void Uppercase(struct Numb *number, unsigned int digit)
{
    int i;
    for(i = 0; i < digit; i++) if(number->num[i] != 0) break;

    number->num[i] = 10 - number->num[i];
    for(i += 1; i < digit; i++)
        number->num[i] = 9 - number->num[i];
    return;
}
void Rounds
(struct Numb *number)
{
    int i, j;
    for(i = 0 ;; i++)
    {
        if(number->num[i] == 0 && i >= number->digit) break;
        number->num[i+1] += number->num[i]/10;
        number->num[i] = number->num[i] % 10;
    }
    for(j = i - 1; j >= 0; j--) if(number->num[j]) break;
    number->digit = j+1;
    return;
}
bool Over(struct Numb A, struct Numb B, int b_shift)
{
    if(A.digit > B.digit + b_shift) return true;
    else if(A.digit < B.digit + b_shift) return false;
    for(int i = A.digit -1; i >= b_shift; i--){
        if(A.num[i] > B.num[i - b_shift]) return true;
        else if(A.num[i] < B.num[i - b_shift]) return false;
    }
    for(int i = b_shift - 1; i >= 0; i--)
        if(A.num[i]) return true;
    // 빼는 수가 더 클 시 음수로 값 표시
    return same;
}

struct Numb Plus(struct Numb A, struct Numb B, int shift )
{
    struct Numb Result;
    int digit = MAX(A.digit, B.digit);
    bool Over = Over(A, B, shift);
    INPUT(&Result);

    if(A.negative && B.negative) {
        A.negative = B.negative = false;
        Result.negative = true;
    }

    if(Over == same && A.negative != B.negative) return Result;
    else if(Over == same) Over = true;

     if(A.negative) Bosu(&A, digit);
    if(B.negative) Bosu(&B, digit - shift);

    for(int i = 0; i < shift; i++) Result.num[i] = A.num[i];
      for(int i = shift; i < digit; i++) Result.num[i] = A.num[i] + B.num[i - shift];

    // 양수 덧셈시 자릿수가 커질경우 대비함
    if(A.negative || B.negative) Result.num[digit - 1] %= 10;

    Result.digit = digit;

    // 결과값이 마이너스일때
    if((A.negative && Over || (B.negative && !Over))){
        Bosu(&Result, Result.digit);
        Result.negative = true;
    } else if(!Result.negative) Result.negative = false;

    Rounds(&Result);

    if(Result.digit == 0) Result.digit = 1;
    return Result;
}
struct Numb negative(struct Numb A, struct Numb B)
{
    B.negative = !B.negative;
    return Plus(A, B, 0);
}
struct Numb Multiply(struct Numb A, struct Numb B)
{
    struct Numb Result;
    INPUT(&Result);
    // 곱셈시 부호 결정
    Result.negative = A.negative ^ B.negative;
    Result.digit = A.digit + B.digit;
    // 범위 초과
    if(Result.digit > MAXIMUM){
        Result.digit = MAXIMUM + 1;
        return Result;
    }
    for(int i = 0; i < A.digit; i++)
        for(int j = 0; j < B.digit; j++)
            Result.num[i+j] += A.num[i] * B.num[j];
    Rounds(&Result);
    return Result;
}
struct Numb Divide(struct Numb A, struct Numb B)
{
    struct Numb Result, K;
    INPUT(&Result);
    INPUT(&K);

    if(A.digit < B.digit) {
        Result.digit = 1;
        return Result;
    }
    //부호 선정
    Result.negative = A.negative ^ B.negative;
    Result.digit = A.digit - B.digit;
    A.negative = false;
    B.negative = true;
    K = A;
    for(int shift = A.digit - B.digit; shift >= 0; shift--)
    {
        while(K.digit){
            K = Plus(K, B, shift);
            if(K.negative) break;
            Result.num[shift]++;
        }
        if(!K.digit) break;
        B.negative = false;
        K = Plus(K, B, shift);
        B.negative = true;
    }

    Rounds(&Result);

    return Result;
}
