#ifndef __INPUT_H__
#define __INPUT_H__
#define MAXIMUM 300

///�Ҹ��� �ڷ� ����
typedef int bool;
#define true 1
#define false 0
#define same -1

struct Numb {
    int num[MAXIMUM];
    bool negative;
    int digit;
};

void INPUT(struct Number *number);
void digitconstruct(struct Number *number);
void CALCULATE(struct Number *A, struct Number *B, char *oper);

#endif // __INPUT__
