#include <stdio.h>
#include "INPUT.h"
void INPUT(struct Numb *number)
{
    number->digit = number->negative = 0;
    for(int i = 0; i < MAXIMUM; i++) number->num[i] = 0;
    return;
}
void digitconstruct(struct Numb *number)
{
    int i;
    for(i = number->digit - 1; i >= 0; i--) if(number->num[i]) break;

    if(i == -1) number->digit = 1;
    else number->digit = i + 1;

    return ;
}
void CALCULATE(struct Numb *A, struct Numb *B, char *oper)
{
    char array[MAXIMUM * 2 + 50];
    int num1[MAXIMUM] = {0}, num2[MAXIMUM] = {0};

    printf("������ �Է��ϼ���: ");
    fflush(stdin);
    gets(array);
    ///  ���� Ŀ�ǵ�
    if(array[0] == '\n') {*oper = 'E'; return;}

    for(int i = 0; array[i] != '\0'; i++)
    {

        if(A->digit == 0 && array[i] == 'a' && array[i+1] == 'n' && array[i+2] == 's'){
            A->digit = -1;
            i += 2;
            continue;
        }
        if(B->digit == 0 && *oper != 0 && array[i] == 'a' && array[i+1] == 'n' && array[i+2] == 's'){
            B->digit = -1;
            i+=2;
            continue;
        }

        ///���� Ȯ��
        if(A->digit ==0 && array[i] == '-') {A->negative = true; continue;}
        if(*oper != 0 && array[i] == '-') {B->negative = true; continue;}

        if(array[i] > '9' || array[i] < '0')
        {
            if(*oper != 0) {*oper = 'E'; return;}
            *oper = array[i];
            continue;
        }
        if(*oper == 0) num1[A->digit++] = array[i] - '0';
        else num2[B->digit++] = array[i] - '0';
    }
    for(int i = 0; i < A->digit; i++) A->num[i] = num1[A->digit - i - 1];
    for(int i = 0; i < B->digit; i++) B->num[i] = num2[B->digit - i - 1];

    digitconstruct(A);
    digitconstruct(B);

    return;
}
