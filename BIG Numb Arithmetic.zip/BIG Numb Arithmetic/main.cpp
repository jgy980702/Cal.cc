#include <stdio.h>
#include "INPUT.h"
#include "Arithmetic.h"
char Array(struct Number *number)
{
    if(number->digit == 0) {number->digit =1; number->isminus = false;}
    if(number->isminus) printf("-");
    int i = number->digit;
    for(i -1; i >= 0; i--) printf("%c", number->num[i] + '0');
    return ' ';
}
int main()
{
    struct Number A, B, Result, C;
    bool isminus;
    char oper;

    ///�ִ� �ڸ��� ǥ��
    printf("MAXIMUM = %d\n\n", MAXIMUM);

    INPUT(&C);
    while(1) {
        oper = 0;
        INPUT(&A);
        INPUT(&B);
        INPUT(&Result);

        Input(&A, &B, &oper);

        ///��� ��ȣ ǥ��
        negative = C.negative;
        C.negative = A.negative ^ negative;
        if(A.digit == -1) A = C;
        C.negative = B.negative ^ negative;
        if(B.digit == -1) B = C;

        if(oper == '!') return 0;
        else if(oper == '+') Result = Plus(A, B, 0);
        else if(oper == '-') Result = Minus(A, B);
        else if(oper == '*') Result = Multiply(A, B);
        else if(oper == '/') Result = Divide(A, B);
        else {
            printf("\n�Է� ���� \n\n");
            continue;
        }
        if(Result.digit == MAXIMUM + 1){
            printf("\n�ʹ� ū �� �Դϴ� \n\n");
            continue;
        }

        printf("\n�����  :  ");
        Array(&A); printf(" %c ",oper);
        Array(&B); printf(" = ");
        Array(&Result); printf("\n\n\n");

        C = Result;
    }
}
