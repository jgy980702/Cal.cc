#ifndef __Arithmetic_H__
#define __Arithmetic_H__
#include "INPUT.h"

void Uppercase(struct Numb *number, unsigned int digit);
void Rounds(struct Numb *number);
bool Over(struct Numb A, struct Numb B, int b_shift);

struct Numb Plus(struct Numb A, struct Numb B, int b_shift);
struct Numb Minus(struct Numb A, struct Numb B);
struct Numb Multiply(struct Numb A, struct Numb B);
struct Numb Divide(struct Numb A, struct Numb B);

#endif // Arithmetic_H_INCLUDED
